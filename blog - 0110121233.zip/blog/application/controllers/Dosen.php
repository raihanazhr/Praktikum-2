<?php
class Dosen extends CI_Controller{
    public function index(){
        $this->load->model('Dosen_model','dosen1');

        $this->dosen1->nidn='022123';
        $this->dosen1->pendidikan='S2';

        $this->load->model('Dosen_model','dosen2');

        $this->dosen2->nidn='022457';
        $this->dosen2->pendidikan='S1';

        $list_dsn = [$this->dosen1, $this->dosen2];
        $data['list_dsn'] = $list_dsn;
        $this->load->view('layouts/header');
        $this->load->view('Dosen/index', $data);
        $this->load->view('layouts/footer');
    }

}
?>
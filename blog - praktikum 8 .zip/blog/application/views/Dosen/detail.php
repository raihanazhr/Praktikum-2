<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosen</title>
</head>
<body>
    <h3>Dosen</h3>
    <table border="1" class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>NIDN</th>
                <th>nama</th>
                <th>Pendidikan</th>
                <th>tempat lahir</th>
                <th>tanggal lahir</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $dosn->id ?></td>
                <td><?php echo $dosn->nidn ?></td>
                <td><?php echo $dosn->nama ?></td>
                <td><?php echo $dosn->pendidikan ?></td>
                <td><?php echo $dosn->tmp_lahir ?></td>
                <td><?php echo $dosn->tgl_lahir ?></td>
            </tr>
        </tbody>
    </table>
</body>
</html>
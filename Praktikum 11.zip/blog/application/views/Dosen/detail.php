<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dosen</title>
</head>
<body>
    <h3>Dosen</h3>
    <table border="1" class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>NIDN</th>
                <th>nama</th>
                <th>Gender</th>
                <th>Pendidikan</th>
                <th>tempat lahir</th>
                <th>tanggal lahir</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $dosn->id ?></td>
                <td><?php echo $dosn->nidn ?></td>
                <td><?php echo $dosn->nama ?></td>
                <td><?php echo $dosn->gender ?></td>
                <td><?php echo $dosn->pendidikan ?></td>
                <td><?php echo $dosn->tmp_lahir ?></td>
                <td><?php echo $dosn->tgl_lahir ?></td>
            </tr>
        </tbody>
    </table>
    <div class="col-md-5 mb-3">
        <div class="card">
            <div class="card-body">
                <div class="d-flex flex-column align-items-center text-center">
                    <img src="<?=base_url()?>uploads/photos/<?=$dosn->id?>.jpg" alt="" width="300" />
                    <div class="mt-4">
                        <h4><?=$dosn->nama?></h4>
                        <p>Foto Dosen</p>
                        <?php echo $error;?>
                        <br/>
                        <a href="https://elena.nurulfikri.ac.id/" target="_blank">
                        <button class="btn btn-outline-info">instagram</button></a>
                        <?php echo form_open_multipart('dosen/upload');?>
                        <input type="file" name="foto" size="300" />
                        <input type="hidden" name="iddosen" value="<?=$dosn->id?>"/>
                        <br>
                        <input type="submit" value="upload foto" class="btn btn-primary"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>
</html>